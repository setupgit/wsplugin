<?php // Silence is golden _ vermavishal244@gmail.com
defined( 'ABSPATH' ) or die( "Really? Can't Access" );